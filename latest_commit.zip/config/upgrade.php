<?php
return [
    'official_api_url' => 'https://feiniao.paheng.net/api/',
    'version'    => '4.08.36',
];

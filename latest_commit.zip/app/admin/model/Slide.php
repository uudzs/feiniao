<?php

namespace app\admin\model;

use think\Model;

class Slide extends Model
{

}

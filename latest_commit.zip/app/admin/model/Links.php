<?php

declare (strict_types = 1);

namespace app\admin\model;

use think\Model;

class Links extends Model
{

}

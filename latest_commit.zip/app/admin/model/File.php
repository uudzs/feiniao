<?php

namespace app\admin\model;

use think\Model;

// 关键字模型
class File extends Model
{

}

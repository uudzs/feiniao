<?php

namespace app\admin\model;

use think\Model;

class SlideInfo extends Model
{

}

<?php
// 这是系统自动生成的middleware定义文件
return [
    //验证操作
    //\app\api\middleware\Auth::class,
    \app\api\middleware\CrossOrigin::class,
];

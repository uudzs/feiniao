<?php

declare(strict_types=1);

namespace app\home\controller;

use app\home\BaseController;

class Withdraw extends BaseController
{

    /**
     * 提现
     */
    public function index()
    {
        return view();
    }

    /**
     * 提现记录
     */
    public function log()
    {
        return view();
    }
}

<?php

declare(strict_types=1);

namespace app\home\controller;

use app\home\BaseController;

class Vip extends BaseController
{

    /**
     * VIP中心
     */
    public function index()
    {
        return view();
    }

    public function log() {
        return view();
    }
}

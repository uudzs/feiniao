<?php

declare(strict_types=1);

namespace app\home\controller;

use app\home\BaseController;

class Coin extends BaseController
{

    /**
     * 金币记录
     */
    public function index()
    {
        return view();
    }
}

<?php

return [
   'welcome' => 'Welcome',
   'i18n' => 'Multilingual Settings',
];

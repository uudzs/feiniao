<?php

return [
   'welcome'  => '欢迎使用',
   'i18n' => '多语言设置',
];

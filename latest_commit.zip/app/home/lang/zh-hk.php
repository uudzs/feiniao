<?php

return [
   'welcome' => '歡迎使用',
   'i18n'    => '多語言設定',
];

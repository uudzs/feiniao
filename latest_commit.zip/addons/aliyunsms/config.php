<?php

return array (
  'product' => 
  array (
    'title' => 'product',
    'type' => 'string',
    'value' => 'Dysmsapi',
    'tips' => '如 Dysmsapi',
  ),
  'access_key_id' => 
  array (
    'title' => 'AccessKeyId',
    'type' => 'string',
    'value' => '',
    'tips' => '你的Key',
  ),
  'access_key_secret' => 
  array (
    'title' => 'AccessKeySecret',
    'type' => 'string',
    'value' => '',
    'tips' => '你的secret',
  ),
  'sign_name' => 
  array (
    'title' => '签名',
    'type' => 'string',
    'value' => '',
    'tips' => '一般为主体名称',
  ),
  'region' => 
  array (
    'title' => 'region',
    'type' => 'string',
    'value' => '',
    'tips' => '如 cn-hangzhou',
  ),
  'domain' => 
  array (
    'title' => '域名',
    'type' => 'string',
    'value' => 'dysmsapi.aliyuncs.com',
    'tips' => '如 dysmsapi.aliyuncs.com',
  ),
  'template_code' => 
  array (
    'title' => '短信模板',
    'type' => 'string',
    'value' => '',
    'tips' => '以SMS_开头',
  ),
);

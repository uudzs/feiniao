<?php

return array (
  'username' => 
  array (
    'title' => '畅言用户名',
    'type' => 'string',
    'value' => '',
    'tips' => '请填写畅言用户名',
  ),
  'password' => 
  array (
    'title' => '畅言密码',
    'type' => 'string',
    'value' => '',
    'tips' => '请填写畅言密码',
  ),
  'siteid' => 
  array (
    'title' => '启用站点',
    'type' => 'string',
    'value' => '',
    'tips' => '请选择启用的站点',
  ),
  'pc_script' => 
  array (
    'title' => 'PC端安装代码',
    'type' => 'string',
    'value' => '',
    'tips' => '自动生成',
  ),
  'wap_script' => 
  array (
    'title' => 'WAP端安装代码',
    'type' => 'string',
    'value' => '',
    'tips' => '自动生成',
  ),
  'adaptive_script' => 
  array (
    'title' => '自适应安装代码',
    'type' => 'string',
    'value' => '',
    'tips' => '自动生成',
  ),
  'pc_scoring_script' => 
  array (
    'title' => 'PC打分版安装代码',
    'type' => 'string',
    'value' => '',
    'tips' => '自动生成',
  ),
);

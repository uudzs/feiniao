<?php

return array (
  'mode' => 
  array (
    'title' => '模式',
    'type' => 'radio',
    'options' => 
    array (
      'fixed' => '固定',
      'random' => '随机',
    ),
    'value' => 'random',
    'tips' => '随机切换只支持七天内图片',
  ),
  'pic' => 
  array (
    'title' => '固定图片',
    'type' => 'image',
    'value' => 'https://waiwenju.oss-cn-qingdao.aliyuncs.com/202408/42a1e700d091a8a79ed71351e4b43833.jpg',
    'tips' => '选择固定则需要上传此图片',
  ),
);

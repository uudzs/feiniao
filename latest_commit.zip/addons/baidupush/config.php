<?php
return array(
    'site' =>
    array(
        'title' => '域名',
        'type' => 'string',
        'value' => '',
        'tips' => '在搜索资源平台验证的站点，比如www.example.com',
    ),
    'token' =>
    array(
        'title' => '密钥',
        'type' => 'string',
        'value' => '',
        'tips' => '百度官方获取',
    ),
);

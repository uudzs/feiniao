<?php

return array (
  'maxemptycaijinum' => 
  array (
    'title' => '最大空采集次数',
    'type' => 'string',
    'value' => 5,
    'tips' => '超过此次数将跳过不会采集',
  ),
  'downcover' => 
  array (
    'title' => '下载封面图',
    'type' => 'radio',
    'options' => 
    array (
      1 => '是',
      0 => '否',
    ),
    'value' => 1,
    'tips' => '下载可能会占用空间，请认真选择',
  ),
);

<?php

namespace addons\caiji\controller;

use think\facade\Db;
use think\facade\View;
use app\admin\facade\ThinkAddons;
use think\facade\App;
use think\facade\Session;

class Index
{

    // 配置信息
    private $config = [];
    private $addons_name = 'caiji';

    // 初始化
    public function __construct()
    {
        $config    = ThinkAddons::config($this->addons_name);
        $configVal = [];
        foreach ($config as $k => $v) {
            $configVal[$k] = $v['value'] ?? '';
        }
        $this->config = $configVal;
        View::assign('config', $config);
        require_once app()->getRootPath() . 'addons' . DIRECTORY_SEPARATOR . $this->addons_name . DIRECTORY_SEPARATOR . 'common.php';
    }

    private function auth()
    {
        $session_admin = get_config('app.session_admin');
        if (!Session::has($session_admin)) {
            die;
        }
    }

    private function temp()
    {
        return App::getRootPath() . 'addons' . DIRECTORY_SEPARATOR . $this->addons_name . DIRECTORY_SEPARATOR . 'view' . DIRECTORY_SEPARATOR . app('request')->controller() . DIRECTORY_SEPARATOR . app('request')->action() . '.html';
    }

    public function rule()
    {
        $this->auth();
        if (request()->isAjax()) {
            $param = get_params();
            $where = [];
            if (!empty($param['keywords'])) {
                $where[] = ['rule_title', 'like', '%' . $param['keywords'] . '%'];
                unset($param['keywords']);
            }
            $rows = empty($param['limit']) ? get_config('app.page_size') : $param['limit'];
            $order = empty($param['order']) ? 'cid desc' : $param['order'];
            $list = Db::name('addons_caiji_rule')->field('cid,rule_title,rule,status,cj,scode')->where($where)->order($order)->paginate($rows, false, ['query' => $param]);
            $list = $list ? $list->toArray() : [];
            $rule = Db::name('addons_caiji_rule')->field('cid,rule_title')->where(['status' => 1, 'cj' => 2])->order('cid desc')->select()->toArray();
            $rules = array_column($rule, null, 'cid');
            foreach ($list['data'] as $k => $v) {
                if ($v['cj'] == 1 && isset($rules[$v['rule']])) {
                    $list['data'][$k]['chapter_rule'] = $rules[$v['rule']]['rule_title'];
                } else {
                    $list['data'][$k]['chapter_rule'] = '--';
                }
                $list['data'][$k]['category_name'] = Db::name('category')->where('id', $v['scode'])->value('name');
            }
            return table_assign(0, '', $list);
        }
    }

    public function status()
    {
        $this->auth();
        if (request()->isAjax()) {
            $param = get_params();
            $id = $param['id'];
            if (!$id) {
                return to_assign(1, '参数错误');
            }
            if (!isset($param['status'])) {
                return to_assign(1, '参数错误');
            }
            unset($param['id']);
            Db::name('addons_caiji_rule')->where('cid', $id)->strict(false)->field(true)->update($param);
            return to_assign();
        } else {
            return to_assign(1, '请求失败');
        }
    }

    public function add()
    {
        $this->auth();
        $param = get_params();
        if (request()->isAjax()) {
            $type = $param['type'] ?: 'book';
            if (isset($param['chapterurltype']) && intval($param['chapterurltype']) == 1) {
                $param['chapterurl'] = '000';
            } else {
                $param['chapterurl'] = '';
            }
            unset($param['cid'], $param['cjcur'], $param['rule'], $param['status'], $param['type'], $param['chapterurltype']);
            if ($type == 'chapter') {
                $param['cj'] = 2;
            } else {
                $param['cj'] = 1;
            }
            foreach ($param as $k => $v) {
                //$param[$k] = addslashes($v);
                $param[$k] = htmlspecialchars($v);
            }
            if (!isset($param['scode'])) $param['scode'] = 0;
            if (!isset($param['num2'])) $param['num2'] = '';
            if (!isset($param['chapterurl'])) $param['chapterurl'] = '';
            if (!isset($param['chapterurlrep1'])) $param['chapterurlrep1'] = '';
            if (!isset($param['chapterurlrep2'])) $param['chapterurlrep2'] = '';
            if (!isset($param['chapterurlrep'])) $param['chapterurlrep'] = '';
            if (!isset($param['author'])) $param['author'] = '';
            if (!isset($param['authorrep'])) $param['authorrep'] = '';
            if (!isset($param['name'])) $param['name'] = '';
            if (!isset($param['namerep'])) $param['namerep'] = '';
            if (!isset($param['description'])) $param['description'] = '';
            if (!isset($param['descriptionrep'])) $param['descriptionrep'] = '';
            if (!isset($param['ico'])) $param['ico'] = '';
            if (!isset($param['icorep'])) $param['icorep'] = '';
            if (!isset($param['subtitle'])) $param['subtitle'] = '';
            if (!isset($param['subtitlerep'])) $param['subtitlerep'] = '';
            if (!isset($param['subscode'])) $param['subscode'] = '';
            if (!isset($param['subscoderep'])) $param['subscoderep'] = '';
            if (!isset($param['content'])) $param['content'] = '';
            if (!isset($param['contentrep'])) $param['contentrep'] = '';
            if (!isset($param['max_chapter_caijinum'])) $param['max_chapter_caijinum'] = 0;
            $result = Db::name('addons_caiji_rule')->strict(false)->field(true)->insertGetId($param);
            if ($result !== false) {
                return to_assign(0, '添加成功');
            } else {
                return to_assign(1, '添加失败');
            }
        } else {
            $type = $param['type'] ?: 'book';
            if ($type == 'book') {
                $rule = Db::name('addons_caiji_rule')->where(['status' => 1, 'cj' => 2])->order('cid desc')->select()->toArray();
                View::assign('rule', $rule);
            }
            View::assign('type', $type);
            $genres = Db::name('category')->where(['status' => 1])->order('ordernum asc')->select()->toArray();
            View::assign('genres', $genres);
            return view($this->temp());
        }
    }

    public function config()
    {
        $this->auth();
        $param = get_params();
        if (request()->isAjax()) {
            if (!isset($param['maxemptycaijinum']) || intval($param['maxemptycaijinum']) <= 0) {
                return to_assign(1, '最大空采集次数必须大于0');
            }
            $file = app()->getRootPath() . 'addons' . DIRECTORY_SEPARATOR . $this->addons_name . DIRECTORY_SEPARATOR . 'config.php';
            if (!is_file($file)) {
                return to_assign(1, '配置文件不存在');
            }
            $config = include $file;
            if (empty($config) || !isset($config['maxemptycaijinum']) || !isset($config['downcover'])) {
                return to_assign(1, '配置文件为空');
            }
            $config['maxemptycaijinum']['value'] = intval($param['maxemptycaijinum']);
            $config['downcover']['value'] = intval($param['downcover']);
            if ($handle = fopen($file, 'w')) {
                fwrite($handle, "<?php\n\n" . "return " . var_export($config, TRUE) . ";\n");
                fclose($handle);
                return to_assign(0, '设置成功');
            } else {
                return to_assign(1, '文件没有写入权限');
            }
        } else {
            return view($this->temp());
        }
    }

    public function edit()
    {
        $this->auth();
        $param = get_params();
        $id = isset($param['id']) ? $param['id'] : 0;
        if (request()->isAjax()) {
            if (isset($param['chapterurltype']) && intval($param['chapterurltype']) == 1) {
                $param['chapterurl'] = '000';
            } else {
                $param['chapterurl'] = '';
            }
            unset($param['id'], $param['cj'], $param['cjcur'], $param['status'], $param['chapterurltype']);
            foreach ($param as $k => $v) {
                //$param[$k] = addslashes($v);
                $param[$k] = htmlspecialchars($v);
            }
            $result = Db::name('addons_caiji_rule')->where('cid', $id)->strict(false)->field(true)->update($param);
            if ($result !== false) {
                return to_assign(0, '操作成功');
            } else {
                return to_assign(1, '操作失败');
            }
        } else {
            $detail = Db::name('addons_caiji_rule')->where('cid', $id)->find();
            foreach ($detail as $k => $v) {
                if (strstr($k, 'rep')) {
                    $v = decode_string($v);
                    //$v = str_replace('&', '&amp;', $v);
                } else {
                    $v = decode_slashes($v);
                }
                $detail[$k] = $v ? htmlspecialchars_decode($v, ENT_QUOTES) : $v;
            }
            if ($detail['cj'] == 1) {
                $rule = Db::name('addons_caiji_rule')->where(['status' => 1, 'cj' => 2])->order('cid desc')->select()->toArray();
                View::assign('rule', $rule);
            }
            $genres = Db::name('category')->where(['status' => 1])->order('ordernum asc')->select()->toArray();
            View::assign('genres', $genres);
            View::assign('detail', $detail);
            return view($this->temp());
        }
    }

    public function export()
    {
        $this->auth();
        if (request()->isAjax()) {
            $param = get_params();
            if (!isset($param['cid']) || empty($param['cid'])) {
                return to_assign(1, '参数不存在');
            }
            $list = Db::name('addons_caiji_rule')->where('cid', 'in', $param['cid'])->select();
            return table_assign(0, '', ['data' => base64_encode(json_encode($list->toArray()))]);
        }
    }

    public function import()
    {
        $this->auth();
        if (request()->isAjax()) {
            $param = get_params();
            if (!isset($param['rule']) || empty($param['rule'])) {
                return to_assign(1, '参数不存在');
            }
            $rule = base64_decode($param['rule']);
            if (empty($rule)) {
                return to_assign(1, '参数不存在');
            }
            $rule = json_decode($rule, true);
            if (empty($rule)) {
                return to_assign(1, '参数不存在');
            }
            $rule = array_column($rule, null, 'cid');
            $success = $skip = $fail = 0;
            foreach ($rule as $k => $v) {
                if ($v['cj'] == 1) {
                    $where = [
                        'cj' => 1,
                        'url' => $v['url'],
                        'urlrep1' => $v['urlrep1'],
                        'urlrep2' => $v['urlrep2'],
                        'urlyes' => $v['urlyes'],
                        'urlno' => $v['urlno'],
                        'chapterurl' => $v['chapterurl'],
                        'chapterurlrep1' => $v['chapterurlrep1'],
                        'chapterurlrep2' => $v['chapterurlrep2'],
                        'chapterurlrep' => $v['chapterurlrep'],
                        'title' => $v['title'],
                        'titlerep' => $v['titlerep'],
                        'author' => $v['author'],
                        'authorrep' => $v['authorrep'],
                        'name' => $v['name'],
                        'namerep' => $v['namerep'],
                        'description' => $v['description'],
                        'descriptionrep' => $v['descriptionrep'],
                        'ico' => $v['ico'],
                        'icorep' => $v['icorep'],
                        'subtitle' => $v['subtitle'],
                        'subtitlerep' => $v['subtitlerep'],
                        'subscode' => $v['subscode'],
                        'subscoderep' => $v['subscoderep']
                    ];
                    $list = Db::name('addons_caiji_rule')->where($where)->find();
                    $rule_id = 0;
                    if (empty($list)) {
                        unset($v['cid']);
                        if (intval($v['rule']) > 0 && isset($rule[$v['rule']]) && $rule[$v['rule']] && intval($rule[$v['rule']]['cj']) == 2) {
                            $chapter_rule = $rule[$v['rule']];
                            $where = [
                                'cj' => 2,
                                'urlrep1' => $chapter_rule['urlrep1'],
                                'urlrep2' => $chapter_rule['urlrep2'],
                                'title' => $chapter_rule['title'],
                                'titlerep' => $chapter_rule['titlerep'],
                                'content' => $chapter_rule['content'],
                                'contentrep' => $chapter_rule['contentrep']
                            ];
                            unset($chapter_rule['cid']);
                            $chapter = Db::name('addons_caiji_rule')->where($where)->find();
                            if (empty($chapter)) {
                                $rule_id = Db::name('addons_caiji_rule')->strict(false)->field(true)->insertGetId($chapter_rule);
                                if ($rule_id !== false) {
                                    $success++;
                                } else {
                                    $fail++;
                                }
                            } else {
                                $rule_id = $chapter['cid'];
                            }
                        }
                    } else {
                        $skip++;
                        continue;
                    }
                    $v['rule'] = $rule_id;
                    $result = Db::name('addons_caiji_rule')->strict(false)->field(true)->insertGetId($v);
                    if ($result !== false) {
                        $success++;
                    } else {
                        $fail++;
                    }
                }
                if ($v['cj'] == 2) {
                    $chapter_rule = $v;
                    $where = [
                        'cj' => 2,
                        'urlrep1' => $chapter_rule['urlrep1'],
                        'urlrep2' => $chapter_rule['urlrep2'],
                        'title' => $chapter_rule['title'],
                        'titlerep' => $chapter_rule['titlerep'],
                        'content' => $chapter_rule['content'],
                        'contentrep' => $chapter_rule['contentrep']
                    ];
                    unset($chapter_rule['cid']);
                    $chapter = Db::name('addons_caiji_rule')->where($where)->find();
                    if (empty($chapter)) {
                        $result = Db::name('addons_caiji_rule')->strict(false)->field(true)->insertGetId($chapter_rule);
                        if ($result !== false) {
                            $success++;
                        } else {
                            $fail++;
                        }
                    } else {
                        $skip++;
                        continue;
                    }
                }
            }
            $msg = '导入结果：成功(' . $success . ')，跳过(' . $skip . ')，失败(' . $fail . ')。';
            return to_assign(0, $msg);
        }
    }

    public function test()
    {
        $this->auth();
        $param = get_params();
        $id = isset($param['id']) ? $param['id'] : 0;
        $detail = Db::name('addons_caiji_rule')->where('cid', $id)->find();
        foreach ($detail as $k => $v) {
            $v = decode_string($v);
            $detail[$k] = $v;
        }
        $url = $detail['url'];
        $num1 = $detail['num1'];
        $num2 = $detail['num2'];
        $urlrep1 = $detail['urlrep1'];
        $urlrep2 = $detail['urlrep2'];
        $urlyes = $detail['urlyes'];
        $urlno = $detail['urlno'];
        $testurl = $detail['testurl'];
        !$num1 ? $num1 = 1 : '';
        !$num2 ? $num2 = 1 : '';
        $x = rand($num1, $num2); //随机页码
        $url = trim($url);
        $url = str_replace("\n", PHP_EOL, $url);
        $arr = explode(PHP_EOL, $url); //多行转为数组
        shuffle($arr); //随机打乱数组
        $url = $arr[0]; //取第一个
        $url = str_replace('[page]', $x, $url); //替换页码标识
        $h = caiji_request($url); //获取内容
        $h = caiji_rep($h, $urlrep1, $urlrep2); //取网址内容区块     
        $arr = caiji_href($h, $url, $urlyes, $urlno); //获取网址
        $ii = 0;
        $list01 = $list02 = '';
        foreach ($arr as $k => $v) {
            $ii++;
            $list01 .= '
                    <tr>
                        <td>' . $ii . '</td>
                        <td>' . $v . '</td>
                    </tr>';
            if ($ii >= 3) {
                break;
            }
        }
        if (!$list01) {
            $list01 .= '
	                <tr>
	                    <td colspan="4">
		                    <p style="color:red;font-size:16px;padding:10px 0px">无法获取列表...</p>
		                    <p>请按以下步骤检查：</p>
		                    <p>1、浏览器打开网址 <a style="color:blue" href="' . $url . '" target="_blank">' . $url . '</a>，检查目标站是否能正常打开</p>
		                    <p>2、如果目标站打不开，那么，采集规则已失效，此时找客服更换采集规则</p>
		                    <p>3、如果测试结果为“空白页、乱码、或其它报错”，说明目标站防采集，正常情况应该显示目标站页面（排版错乱属正常）</p>
		                    <p>4、步骤3中：不能显示页面，说明目标站防采集，要更换采集规则；能显示页面，说明规则失效，要修复采集规则</p>		              
	                    </td>
	                </tr>';
        } else {
            $list01 .= '
	                <tr>
	                    <td>...</td>
	                    <td>......</td>
	                </tr>';
            if (!$testurl) {
                shuffle($arr);
                $testurl = $arr[0];
            }
        }
        if (!$testurl) {
            $list02 = '
	                <tr>
	                    <td colspan="4">缺少测试地址...</td>
	                </tr>';
        } else {
            $h = caiji_request($testurl);
            foreach ($detail as $k => $v) {
                $xarr = array('cid', 'cj', 'cjcur', 'rule', 'rule_title', 'status', 'scode', 'url', 'num1', 'num2', 'urlrep1', 'urlrep2', 'urlyes', 'urlno', 'testurl');
                if ((in_array($k, $xarr) && $k != 'subscode') || strstr($k, 'rep') || !$v) {
                    continue;
                }
                if ($k == 'chapterurl') {
                    if ($v == '000') {
                        $v = $testurl;
                        $v = caiji_repmini($id, $v, $v, $detail[$k . 'rep']);
                    } else {
                        $v = caiji_repmini($id, $h, $v, $detail[$k . 'rep']);
                    }
                    if ($v) {
                        $v = '<a href="' . $v . '" target="_blank">' . $v . '</a>';
                    }
                } else {
                    if ($k != 'max_chapter_caijinum') $v = caiji_repmini($id, $h, $v, $detail[$k . 'rep']);
                }
                if ($k == 'content') {
                    $s = ' style="background:#fff;text-indent:0px;padding:5px 8px"';
                    $v = escape_string($v);
                    list($num, $v) = countWordsAndContent($v, true);
                } else {
                    $s = '';
                }
                $list02 .= '
                        <tr>
                            <td>' . $k . '</td>
                            <td' . $s . '>' . nl2br($v) . '</td>
                        </tr>';
            }
        }
        $pbstr = 'list01,url,list02,testurl';
        $pbstr = explode(',', $pbstr);
        foreach ($pbstr as $v) {
            $pbarr[$v] = $$v;
        }
        View::assign('pbarr', $pbarr);
        View::assign('detail', $detail);
        return view($this->temp());
    }

    public function delete()
    {
        $this->auth();
        $id = get_params("id");
        if (empty($id)) {
            return to_assign(1, '参数错误');
        }
        if (Db::name('addons_caiji_rule')->where('cid', $id)->delete() !== false) {
            return to_assign(0, "删除成功");
        } else {
            return to_assign(1, "删除失败");
        }
    }

    public function caiji()
    {
        $this->auth();
        $param = get_params();
        $id = isset($param['id']) ?  intval($param['id']) : 0;
        if (request()->isAjax()) {
            $rule = Db::name('addons_caiji_rule')->where('cid', $id)->find();
            if (empty($rule) || $rule['cj'] == 2) {
                return to_assign(0, '', '规则不存在');
            }
            $str = '';
            //优先采集未采集的
            $total = Db::name('addons_caiji_book')->where(['ruleid' => $id, 'chapters' => 0, ['num', '<', $this->config['maxemptycaijinum']]])->count();
            if (intval($total) > 0) {
                $book = Db::name('addons_caiji_book')->where(['ruleid' => $id, 'chapters' => 0, ['num', '<', $this->config['maxemptycaijinum']]])->order('id asc')->find();
                $count = Db::name('addons_caiji_chapter')->where(['bookid' => $book['id'], 'on' => 0, ['num', '<', $this->config['maxemptycaijinum']]])->count();
                if ($count > 0) {
                    $success = $this->caijiChapterInfo($book['id']);
                    $str .= '<li>成功采集章节：' . $success . '。</li>';
                    if (intval($success) > 0) {
                        return to_assign(0, '', $str);
                    }
                } else {
                    if (empty($book['bookid'])) {
                        $result = $this->caijiBookInfo($book['id']);
                        $str .= '<li>采集作品成功：' . $result['success'] . '，跳过：' . $result['skip'] . '，失败：' . $result['fail'] . '。</li>';
                    }
                    $success = $this->caijiChapterUrl($book['id']);
                    $str .= '<li>成功采集章节地址：' . $success . '。</li>';
                    if ($success > 0) {
                        $success = $this->caijiChapterInfo($book['id']);
                        $str .= '<li>成功采集章节：' . $success . '。</li>';
                    }
                }
            }
            //采集作品未采过的
            $total = Db::name('addons_caiji_book')->where(['ruleid' => $id, ['num', '<', $this->config['maxemptycaijinum']]])->count();
            if (intval($total) <= 0) {
                //采集作品网址
                $num = $this->caijiBookUrl($id);
                if ($num <= 0) {
                    $str .= '<li>未采集到新作品地址！</li>';
                } else {
                    $book = Db::name('addons_caiji_book')->where(['ruleid' => $id, ['num', '<', $this->config['maxemptycaijinum']]])->find();
                    if (!empty($book)) {
                        $result = $this->caijiBookInfo($book['id']);
                        $str .= '<li>采集作品成功：' . $result['success'] . '，跳过：' . $result['skip'] . '，失败：' . $result['fail'] . '。</li>';
                        if ($result['success'] > 0) {
                            $success = $this->caijiChapterUrl($book['id']);
                            $str .= '<li>成功采集章节地址：' . $success . '。</li>';
                            $success = $this->caijiChapterInfo($book['id']);
                            $str .= '<li>成功采集章节：' . $success . '。</li>';
                        }
                    } else {
                        $str .= '<li>没有可采集作品！</li>';
                    }
                }
                return to_assign(0, '', $str);
            } else {
                $book = Db::name('addons_caiji_book')->where(['ruleid' => $id, ['num', '<', $this->config['maxemptycaijinum']]])->find();
                $result = $this->caijiBookInfo($book['id']);
                $str .= '<li>采集作品成功：' . $result['success'] . '，跳过：' . $result['skip'] . '，失败：' . $result['fail'] . '。</li>';
                $success = $this->caijiChapterInfo($book['id']);
                $str .= '<li>成功采集章节：' . $success . '。</li>';
                if ($success <= 0) {
                    $success = $this->caijiChapterUrl($book['id']);
                    $str .= '<li>成功采集章节地址：' . $success . '。</li>';
                    if ($success > 0) {
                        $success = $this->caijiChapterInfo($book['id']);
                        $str .= '<li>成功采集章节：' . $success . '。</li>';
                    }
                }
                return to_assign(0, '', $str);
            }
        } else {
            return view($this->temp(), ['id' => $id]);
        }
    }

    public function caijiChapterInfo($bookid = 0)
    {
        $books = [];
        if (intval($bookid) > 0) {
            $books[] = Db::name('addons_caiji_book')->where(['id' => $bookid])->find();
        }
        $i = 0;
        foreach ($books as $k => $v) {
            if (empty($v['bookid'])) continue;
            $book = Db::name('book')->where(['id' => $v['bookid']])->find();
            if (empty($book)) continue;
            $bookrule = Db::name('addons_caiji_rule')->where(['cid' => $v['ruleid']])->find();
            if (empty($bookrule)) {
                continue;
            }
            //每次采集10章
            $chapters = Db::name('addons_caiji_chapter')->where(['bookid' => $v['id'], 'on' => 0])->order('id asc')->select()->toArray();
            $chaptertable = calc_hash_db($v['bookid']); //章节内容表名
            foreach ($chapters as $key => $value) {
                if (empty($value['ruleid'])) continue;
                $rule = Db::name('addons_caiji_rule')->where(['cid' => $value['ruleid']])->find();
                if (empty($rule)) {
                    continue;
                }
                if (intval($rule['status']) <= 0) continue;
                if (intval($rule['cj']) != 2) continue;
                //开始采集
                $caijihtml = caiji_request($value['url']);
                //如果采集失败，则跳过
                if (empty($caijihtml)) {
                    Db::name('addons_caiji_chapter')->where('id', $value['id'])->inc('num')->strict(false)->field(true)->update(['update_time' => time()]);
                    continue;
                }
                $title = decode_string($rule['title']);
                $titlerep = decode_string($rule['titlerep']);
                $content = decode_string($rule['content']);
                $contentrep = decode_string($rule['contentrep']);
                $chapter_title = caiji_repmini($rule['cid'], $caijihtml, $title, $titlerep);
                $chapter_content = caiji_repmini($rule['cid'], $caijihtml, $content, $contentrep);
                if (empty($chapter_title) || empty($chapter_content)) {
                    Db::name('addons_caiji_chapter')->where('id', $value['id'])->inc('num')->strict(false)->field(true)->update(['update_time' => time()]);
                    continue;
                }
                $chapter = Db::name('chapter')->where(array('bookid' => $v['bookid'], 'title' => $chapter_title))->count();
                //标题不一致则修改章节
                if (intval($value['chapterid']) > 0 && intval($chapter) <= 0) {
                    list($wordnum, $content) = countWordsAndContent($chapter_content, true);
                    Db::name('chapter')->where('id', $value['ichapteridd'])->strict(false)->field(true)->update(['title' => $chapter_title, 'wordnum' => $wordnum, 'update_time' => time()]);
                    Db::name($chaptertable)->where('sid', $value['chapterid'])->strict(false)->field(true)->update(['info' => $content]);
                    Db::name('addons_caiji_chapter')->where('id', $value['id'])->inc('num')->strict(false)->field(true)->update(['title' => $chapter_title, 'update_time' => time()]);
                    $i++;
                    continue;
                }
                //新增
                if (intval($chapter) <= 0 && intval($value['chapterid']) <= 0) {
                    $chaps = 1;
                    $serial = Db::name('chapter')->where(array('bookid' => $v['bookid']))->order('chaps desc')->value('chaps');
                    if (!empty($serial)) {
                        $chaps = intval($serial) + 1;
                    }
                    list($wordnum, $content) = countWordsAndContent($chapter_content, true);
                    $data = [
                        'bookid' => $v['bookid'],
                        'authorid' => $book['authorid'],
                        'title' => $chapter_title,
                        'chaps' => $chaps,
                        'status' => 1,
                        'verify' => 1,
                        'trial_time' => 0,
                        'verifyresult' => '',
                        'verifytime' => time(),
                        'wordnum' => $wordnum,
                        'create_time' => time()
                    ];
                    $sid = Db::name('chapter')->strict(false)->field(true)->insertGetId($data);
                    if ($sid !== false) {
                        Db::name($chaptertable)->strict(false)->field(true)->insertGetId(['sid' => $sid, 'info' => $content]);
                        Db::name('addons_caiji_chapter')->where('id', $value['id'])->inc('num')->strict(false)->field(true)->update(['chapterid' => $sid, 'title' => $chapter_title, 'on' => 1, 'update_time' => time()]);
                        $i++;
                    }
                }
            }
            if ($i > 0) {
                $chapters = Db::name('addons_caiji_chapter')->where(array('bookid' => $v['id']))->count();
                Db::name('addons_caiji_book')->where('id', $v['id'])->inc('num')->strict(false)->field(true)->update(['chapters' => $chapters, 'update_time' => time()]);
                Db::name('book')->where('id', $v['bookid'])->strict(false)->field(true)->update(['chapters' => $chapters, 'update_time' => time()]);
            }
        }
        return $i;
    }

    public function caijiBookInfo($bookid = 0)
    {
        if (intval($bookid) > 0) {
            $books[] = Db::name('addons_caiji_book')->where(['id' => $bookid])->find();
        } else {
            $books = Db::name('addons_caiji_book')->where(['num', '<', $this->config['maxemptycaijinum']])->order('create_time asc')->select()->toArray();
        }
        $success = $fail = $skip = 0;
        foreach ($books as $k => $v) {
            $rule = Db::name('addons_caiji_rule')->where(['cid' => $v['ruleid']])->find();
            if (empty($rule)) {
                Db::name('addons_caiji_book')->where('id', $v['id'])->delete();
                Db::name('addons_caiji_chapter')->where('bookid', $v['id'])->delete();
                $fail++;
                continue;
            }
            if (intval($v['bookid']) > 0) {
                if (intval($v['chapters']) <= 0) {
                    $chapter_count = Db::name('chapter')->where('bookid', $v['bookid'])->count();
                    if (intval($chapter_count) > 0) {
                        Db::name('addons_caiji_book')->where(['id' => $v['id']])->update(['chapters' => $chapter_count]);
                    }
                }
            }
            //开始采集
            $caijihtml = caiji_request($v['url']);
            //如果采集失败，则跳过
            if (empty($caijihtml)) {
                Db::name('addons_caiji_book')->where(['id' => $v['id']])->inc('num')->update(['update_time' => time()]);
                $skip++;
                continue;
            }
            $title = caiji_repmini($rule['cid'], $caijihtml, decode_string($rule['title']), decode_string($rule['titlerep'])); //作品名称
            $author = caiji_repmini($rule['cid'], $caijihtml, decode_string($rule['author']), decode_string($rule['authorrep'])); //作者         
            //如果核心信息未采集到则跳过
            if (empty($title) || empty($author)) {
                Db::name('addons_caiji_book')->where(['id' => $v['id']])->inc('num')->update(['update_time' => time()]);
                $fail++;
                continue;
            }
            $title = strip_tags($title);
            $title = trim($title);
            $author = trim($author);
            $book = Db::name('book')->where('title', $title)->find();
            //不是同一个作品
            if (intval($v['bookid']) > 0 && !empty($book)) {
                if ($book['id'] != $v['bookid']) {
                    Db::name('addons_caiji_book')->where('id', $v['id'])->inc('num')->update(['title' => $title, 'bookid' => $book['id']]);
                    $skip++;
                    continue;
                }
            }
            //如果作品bookid为空则关联
            if (empty($v['bookid']) && !empty($book)) {
                Db::name('addons_caiji_book')->where('id', $v['id'])->inc('num')->update(['title' => $title, 'bookid' => $book['id']]);
                $skip++;
                continue;
            }
            if (empty($book)) {
                $name = caiji_repmini($rule['cid'], $caijihtml, decode_string($rule['name']), decode_string($rule['namerep'])); //分类
                $description = caiji_repmini($rule['cid'], $caijihtml, decode_string($rule['description']), decode_string($rule['descriptionrep'])); //简介
                $ico = caiji_repmini($rule['cid'], $caijihtml, decode_string($rule['ico']), decode_string($rule['icorep'])); //封面
                $subtitle = caiji_repmini($rule['cid'], $caijihtml, decode_string($rule['subtitle']), decode_string($rule['subtitlerep'])); //连载或完结
                $subscode = caiji_repmini($rule['cid'], $caijihtml, decode_string($rule['subscode']), decode_string($rule['subscoderep'])); //字数
                list($genre, $subgenre) = caiji_category($rule['scode'], $name);
                //以作品名称获取拼音字符串
                list($filename, $fn) = cjfilename($title);
                $user = Db::name('author')->where(['nickname' => $author])->find();
                if (empty($user)) {
                    $time = (string) time();
                    $salt = substr(MD5($time), 0, 6);
                    $password = set_salt(20);
                    $data = array(
                        'nickname' => $author,
                        'salt' => $salt,
                        'password' => sha1(MD5($password) . $salt),
                        'ip' => request()->ip(),
                        'create_time' => time(),
                        'status' => 1,
                    );
                    $authorid = Db::name('author')->strict(false)->field(true)->insertGetId($data);
                } else {
                    $authorid = $user['id'];
                    $author = $user['nickname'];
                }
                $title = str_replace("'", "\'", $title);
                $description = str_replace("'", "\'", $description);
                list($jjnum, $description) = countWordsAndContent($description, true);
                $visits = rand(50, 200);
                if (!strstr($ico, 'http')) {
                    $ico = '';
                }
                $bookdata = [
                    'title' => $title,
                    'author' => $author,
                    'authorid' => $authorid,
                    'status' => 1,
                    'words' => $subscode,
                    'genre' => $genre,
                    'subgenre' => $subgenre,
                    'filename' => $filename,
                    'remark' => $description,
                    'hits' => $visits,
                    'cover' => $ico,
                    'isfinish' => isfinish($subtitle),
                    'create_time' => time(),
                ];
                $bookid = Db::name('book')->strict(false)->field(true)->insertGetId($bookdata);
                if ($bookid !== false) {
                    $success++;
                    if (!empty($ico) && intval($this->config['downcover']) > 0) {
                        $cover = ico2local($ico, $bookid);
                        if (!empty($ico)) {
                            Db::name('book')->where('id', $bookid)->strict(false)->field(true)->update(['cover' => $cover]);
                        }
                    }
                    Db::name('addons_caiji_book')->where('id', $v['id'])->strict(false)->field(true)->update(['bookid' => $bookid, 'title' => $title, 'num' => 1, 'on' => 1, 'update_time' => time()]);
                    //重名的话变更当前文件名
                    if ($fn) {
                        $filename = $filename . $bookid;
                        Db::name('book')->where('id', $bookid)->strict(false)->field(true)->update(['filename' => $filename]);
                    }
                } else {
                    $fail++;
                }
            } else {
                Db::name('addons_caiji_book')->where('id', $v['id'])->inc('num')->update(['update_time' => time()]);
                $skip++;
            }
        }
        return ['success' => $success, 'fail' => $fail, 'skip' => $skip];
    }

    public function caijiBookUrl($ruleid = 0)
    {
        $rule = [];
        if (intval($ruleid) > 0) {
            $rule[] = Db::name('addons_caiji_rule')->where(['cid' => $ruleid])->find();
        } else {
            //随机采集一条
            $cids = Db::name('addons_caiji_rule')->field('cid')->where(['status' => 1, 'cj' => 1])->select()->toArray();
            if ($cids) {
                $key = array_rand($cids);
                $cid = $cids[$key];
                $rule[] = Db::name('addons_caiji_rule')->where(['cid' => $cid['cid']])->find();
            }
        }
        $success = 0;
        foreach ($rule as $k => $v) {
            if (intval($v['status']) <= 0) continue;
            if (intval($v['cj']) != 1) continue;
            $url = decode_string($v['url']);
            $num1 = decode_string($v['num1']);
            $num2 = decode_string($v['num2']);
            $urlrep1 = decode_string($v['urlrep1']);
            $urlrep2 = decode_string($v['urlrep2']);
            $urlyes = decode_string($v['urlyes']);
            $urlno = decode_string($v['urlno']);
            $url = str_replace("\n", PHP_EOL, $url);
            $urls = explode(PHP_EOL, $url);
            if (count($urls) > 1) {
                shuffle($urls);
                $url = $urls[0];
            } else {
                $url = $urls[0];
            }
            $url = trim($url);
            $urlx = '[page]';
            if (strstr($url, $urlx)) {
                $page = rand($num1, $num2);
                if (intval($page) > 0) {
                    $url = str_replace($urlx, $page, $url);
                } else {
                    $url = str_replace($urlx, 1, $url);
                }
            }
            $html = caiji_request($url);
            $html = caiji_rep($html, $urlrep1, $urlrep2);
            $books = caiji_href($html, $url, $urlyes, $urlno);
            if (empty($books)) continue;
            foreach ($books as $value) {
                if (empty($value)) continue;
                $hash = cjhash($value);
                $x = Db::name('addons_caiji_book')->where('hash', '=', $hash)->force('hash')->find();
                if (empty($x)) {
                    $o = Db::name('addons_caiji_book')->strict(false)->field(true)->insertGetId(['ruleid' => $v['cid'], 'url' => $value, 'hash' => $hash, 'create_time' => time()]);
                    if ($o !== false) {
                        $success++;
                    }
                }
            }
        }
        return $success;
    }

    public function caijiChapterUrl($bookid = 0)
    {
        if (intval($bookid) > 0) {
            $list[] = Db::name('addons_caiji_book')->where(['id' => $bookid])->find();
        } else {
            $list = Db::name('addons_caiji_book')->where(['num', '<', $this->config['maxemptycaijinum']])->order('create_time asc')->select()->toArray();
        }
        $i = 0;
        foreach ($list as $k => $v) {
            if (intval($v['ruleid']) <= 0) continue;
            $rule = Db::name('addons_caiji_rule')->where(['cid' => $v['ruleid']])->find();
            if (empty($rule)) {
                Db::name('addons_caiji_book')->where('id', $v['id'])->delete();
                Db::name('addons_caiji_chapter')->where('bookid', $v['id'])->delete();
                continue;
            }
            if (empty($v['bookid'])) continue;
            //取章节规则
            $chapter_rule = Db::name('addons_caiji_rule')->where('cid', $rule['rule'])->find();
            if (empty($chapter_rule)) {
                Db::name('addons_caiji_chapter')->where('bookid', $v['id'])->delete();
                continue;
            }
            $max_chapter_caijinum = intval($rule['max_chapter_caijinum']);
            $chapterurl = $rule['chapterurl'];
            if ($chapterurl == '000') {
                $chapterurl = caiji_repmini($rule['cid'], $v['url'], $v['url'], $rule['chapterurlrep']); //章节地址
            } else {
                if (empty($rule['chapterurlrep1']) || empty($rule['chapterurlrep1'])) continue;
                $chapterurlrep1 = decode_string($rule['chapterurlrep1']);
                $chapterurlrep2 = decode_string($rule['chapterurlrep2']);
                $rep1 = $chapterurlrep1 ? str_replace('/', '\/', $chapterurlrep1) : '';
                $rep2 = $chapterurlrep2 ? str_replace('/', '\/', $chapterurlrep2) : '';
                $html = caiji_request($v['url']);
                $pattern = "/$rep1(.*?)$rep2/s";
                preg_match($pattern, $html, $matches);
                if (!isset($matches[1])) continue;
                $chapterurl = $matches[1];
            }
            $cj = decode_string($chapter_rule['cj']);
            if (intval($cj) != 2) continue;
            $urlrep1 = decode_string($chapter_rule['urlrep1']);
            $urlrep2 = decode_string($chapter_rule['urlrep2']);
            $urlyes = decode_string($chapter_rule['urlyes']);
            $urlno = decode_string($chapter_rule['urlno']);
            //开始采集
            $caijihtml = caiji_request($chapterurl);
            $caijihtml = caiji_rep($caijihtml, $urlrep1, $urlrep2);
            $chapter_urls = caiji_href($caijihtml, $chapterurl, $urlyes, $urlno); //章节表列地址
            if (empty($chapter_urls)) continue;
            $l = 0;
            foreach ($chapter_urls as $key => $value) {
                if (empty($value)) {
                    continue;
                }
                if ($max_chapter_caijinum > 0) {
                    if ($l >= $max_chapter_caijinum) break;
                }
                $hash = cjhash($value);
                $x = Db::name('addons_caiji_chapter')->where('hash', '=', $hash)->force('hash')->find();
                if (empty($x)) {
                    $o = Db::name('addons_caiji_chapter')->strict(false)->field(true)->insertGetId(['ruleid' => $chapter_rule['cid'], 'url' => $value, 'bookid' => $v['id'], 'hash' => $hash, 'create_time' => time()]);
                    if ($o !== false) {
                        $l++;
                        $i++;
                    }
                }
            }
        }
        return $i;
    }
}

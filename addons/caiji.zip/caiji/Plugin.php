<?php

namespace addons\caiji;

use think\facade\App;
use think\Addons;
use addons\caiji\controller\index;
use think\facade\Db;

/**
 * 注意名字不可以修改，只能为Plugin
 */
class Plugin extends Addons    // 需继承think\Addons类
{
    private $admin_list = [
        [
            'pid' => 120, //父id
            "src" => "addons/caiji/index/rule", //方法名称
            'title'  => '采集插件-规则', //菜单标题
            'name'   => '采集插件-规则', //名称
            'icon'   => '', //图标
            "menu" => 2, //是否是菜单,1是,2不是
            'sort'   => 0, //默认排序                
            'status' => 1, //状态，1是显示，0是不显示
        ],
        [
            'pid' => 120, //父id
            "src" => "addons/caiji/index/add", //方法名称
            'title'  => '采集插件-规则添加', //菜单标题
            'name'   => '采集插件-规则添加', //名称
            'icon'   => '', //图标
            "menu" => 2, //是否是菜单,1是,2不是
            'sort'   => 0, //默认排序                
            'status' => 1, //状态，1是显示，0是不显示
        ],
        [
            'pid' => 120, //父id
            "src" => "addons/caiji/index/edit", //方法名称
            'title'  => '采集插件-规则修改', //菜单标题
            'name'   => '采集插件-规则修改', //名称
            'icon'   => '', //图标
            "menu" => 2, //是否是菜单,1是,2不是
            'sort'   => 0, //默认排序                
            'status' => 1, //状态，1是显示，0是不显示
        ],
        [
            'pid' => 120, //父id
            "src" => "addons/caiji/index/delete", //方法名称
            'title'  => '采集插件-规则删除', //菜单标题
            'name'   => '采集插件-规则删除', //名称
            'icon'   => '', //图标
            "menu" => 2, //是否是菜单,1是,2不是
            'sort'   => 0, //默认排序                
            'status' => 1, //状态，1是显示，0是不显示
        ],
        [
            'pid' => 120, //父id
            "src" => "addons/caiji/index/config", //方法名称
            'title'  => '采集插件-规则配置', //菜单标题
            'name'   => '采集插件-规则配置', //名称
            'icon'   => '', //图标
            "menu" => 2, //是否是菜单,1是,2不是
            'sort'   => 0, //默认排序                
            'status' => 1, //状态，1是显示，0是不显示
        ],
        [
            'pid' => 120, //父id
            "src" => "addons/caiji/index/test", //方法名称
            'title'  => '采集插件-测试', //菜单标题
            'name'   => '采集插件-测试', //名称
            'icon'   => '', //图标
            "menu" => 2, //是否是菜单,1是,2不是
            'sort'   => 0, //默认排序                
            'status' => 1, //状态，1是显示，0是不显示
        ],
        [
            'pid' => 120, //父id
            "src" => "addons/caiji/index/status", //方法名称
            'title'  => '采集插件-状态设置', //菜单标题
            'name'   => '采集插件-状态设置', //名称
            'icon'   => '', //图标
            "menu" => 2, //是否是菜单,1是,2不是
            'sort'   => 0, //默认排序                
            'status' => 1, //状态，1是显示，0是不显示
        ],
        [
            'pid' => 120, //父id
            "src" => "addons/caiji/index/caiji", //方法名称
            'title'  => '采集插件-采集', //菜单标题
            'name'   => '采集插件-采集', //名称
            'icon'   => '', //图标
            "menu" => 2, //是否是菜单,1是,2不是
            'sort'   => 0, //默认排序                
            'status' => 1, //状态，1是显示，0是不显示
        ],
        [
            'pid' => 120, //父id
            "src" => "addons/caiji/index/export", //方法名称
            'title'  => '采集插件-导出', //菜单标题
            'name'   => '采集插件-导出', //名称
            'icon'   => '', //图标
            "menu" => 2, //是否是菜单,1是,2不是
            'sort'   => 0, //默认排序                
            'status' => 1, //状态，1是显示，0是不显示
        ],
        [
            'pid' => 120, //父id
            "src" => "addons/caiji/index/import", //方法名称
            'title'  => '采集插件-导入', //菜单标题
            'name'   => '采集插件-导入', //名称
            'icon'   => '', //图标
            "menu" => 2, //是否是菜单,1是,2不是
            'sort'   => 0, //默认排序                
            'status' => 1, //状态，1是显示，0是不显示
        ],
    ];

    /**
     * 插件安装方法
     * @return bool
     */
    public function install()
    {
        foreach ($this->admin_list as $key => $value) {
            if (Db::name('admin_rule')->where(['src' => $value['src']])->count()) {
                continue;
            }
            $value['create_time'] = time();
            $rid = Db::name('admin_rule')->strict(false)->field(true)->insertGetId($value);
            $group = Db::name('AdminGroup')->find(1);
            if (!empty($group)) {
                $newGroup['id'] = 1;
                $newGroup['rules'] = $group['rules'] . ',' . $rid;
                Db::name('AdminGroup')->strict(false)->field(true)->update($newGroup);
            }
        }
        clear_cache('adminRules');
        return true;
    }

    /**
     * 插件卸载方法
     * @return bool
     */
    public function uninstall()
    {
        foreach ($this->admin_list as $key => $value) {
            if (Db::name('admin_rule')->where(['src' => $value['src']])->count()) {
                Db::name('admin_rule')->where('src', $value['src'])->delete();
            }
        }
        clear_cache('adminRules');
        return true;
    }

    public function caijiHook($name = '')
    {
        // 当前插件的基础信息，系统优先获取info.ini中的配置信息
        $info = $this->getInfo();
        // 插件禁用后不再进行上传
        if ($info['install'] == 0 || $info['status'] == 0) {
            echo '作品标签插件已禁用或未安装，请启用或安装后再试。';
            exit;
        }
        $config = [];
        $rootPath = App::getRootPath();
        // 获取插件目录路径
        $config_file = $rootPath . 'addons' . DIRECTORY_SEPARATOR . $info['name'] . DIRECTORY_SEPARATOR . 'config.php';
        if (is_file($config_file)) {
            $config = (array) include $config_file;
        }
        if (empty($config)) return false;
        $caiji = new index();
        $total = Db::name('addons_caiji_book')->where(['chapters' => 0, ['num', '<', $config['maxemptycaijinum']['value']]])->count();
        if (intval($total) > 0) {
            $lsit = Db::name('addons_caiji_book')->field('id')->where(['chapters' => 0, ['num', '<', $config['maxemptycaijinum']['value']]])->order('id asc')->select()->toArray();
            foreach ($lsit as $k => $v) {
                $count = Db::name('addons_caiji_chapter')->where(['bookid' => $v['id'], 'on' => 0, ['num', '<', $config['maxemptycaijinum']['value']]])->count();
                if ($count > 0) {
                    $success = $caiji->caijiChapterInfo($v['id']);
                }
            }
        }
        //采集作品未采过的
        $total = Db::name('addons_caiji_book')->where(['on' => 0, ['num', '<', $config['maxemptycaijinum']['value']]])->count();
        if (intval($total) <= 0) {
            $lsit = Db::name('addons_caiji_book')->field('id,bookid')->where(['on' => 0, ['num', '<', $config['maxemptycaijinum']['value']]])->order('id asc')->select()->toArray();
            foreach ($lsit as $k => $v) {
                if (empty($v['bookid'])) {
                    $caiji->caijiBookInfo($v['id']);
                }
                $count = Db::name('addons_caiji_chapter')->where(['bookid' => $v['id']])->count();
                if (intval($count) <= 0) {
                    $success = $caiji->caijiChapterUrl($v['id']);
                    if ($success > 0) {
                        $success = $caiji->caijiChapterInfo($v['id']);
                    }
                } else {
                    $success = $caiji->caijiChapterInfo($v['id']);
                }
            }
            //采集作品网址
            $success = $caiji->caijiBookUrl();
            if ($success > 0) {
                $lsit = Db::name('addons_caiji_book')->field('id,bookid')->where(['on' => 0, ['num', '<', $config['maxemptycaijinum']['value']]])->order('id asc')->select()->toArray();
                foreach ($lsit as $k => $v) {
                    $result = $caiji->caijiBookInfo($v['id']);
                    if ($result['success'] > 0) {
                        $success = $caiji->caijiChapterUrl($v['id']);
                        $success = $caiji->caijiChapterInfo($v['id']);
                    }
                }
            }
        } else {
            $lsit = Db::name('addons_caiji_book')->field('id,bookid')->where(['on' => 0, ['num', '<', $config['maxemptycaijinum']['value']]])->order('id asc')->select()->toArray();
            foreach ($lsit as $k => $v) {
                $result = $caiji->caijiBookInfo($v['id']);
                if ($result['success'] > 0) {
                    $success = $caiji->caijiChapterUrl($v['id']);
                    $success = $caiji->caijiChapterInfo($v['id']);
                }
            }
        }
        echo 'ok';
        exit;
    }
}

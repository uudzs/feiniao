<?php

use think\facade\Db;
use Overtrue\Pinyin\Pinyin;

if (!function_exists('decode_string')) {
    // 字符反转义html实体及斜杠，支持字符串、数组、对象
    function decode_string($string)
    {
        if (! $string)
            return $string;
        if (is_array($string)) { // 数组处理
            foreach ($string as $key => $value) {
                $string[$key] = decode_string($value);
            }
        } elseif (is_object($string)) { // 对象处理
            foreach ($string as $key => $value) {
                $string->$key = decode_string($value);
            }
        } else { // 字符串处理
            $string = stripcslashes($string);
            $string = htmlspecialchars_decode($string, ENT_QUOTES);
        }
        return $string;
    }
}

if (!function_exists('decode_slashes')) {
    // 字符反转义斜杠，支持字符串、数组、对象
    function decode_slashes($string)
    {
        if (!$string)
            return $string;
        if (is_array($string)) { // 数组处理
            foreach ($string as $key => $value) {
                $string[$key] = decode_slashes($value);
            }
        } elseif (is_object($string)) { // 对象处理
            foreach ($string as $key => $value) {
                $string->$key = decode_slashes($value);
            }
        } else { // 字符串处理
            $string = stripcslashes($string);
        }
        return $string;
    }
}

if (!function_exists('preg_replace_r')) {
    // 递归替换
    function preg_replace_r($search, $replace, $subject)
    {
        while (preg_match($search, $subject)) {
            $subject = preg_replace($search, $replace, $subject);
        }
        return $subject;
    }
}

if (!function_exists('caiji_repmini')) {
    function caiji_repmini($cid, $h = null, $xxx = null, $rep = null)
    {
        if ($xxx == '000') {
            if (!$cid) {
                $xxx = '';
                return $xxx;
            }
            $x = Db::name('addons_caiji_rule')->where('cid', $cid)->find();
            $content = $x['content'];
            $contentrep = $x['contentrep'];
            $rep = $xxx . PHP_EOL . $contentrep;
            $xxx = decode_string($content);
            $rep = decode_string($rep);
        }
        $arr = explode('[内容]', $xxx);
        $rep1 = $arr[0];
        $rep2 = isset($arr[1]) ? $arr[1] : '';
        $xxx = caiji_rep($h, $rep1, $rep2, $rep);
        if (strstr($rep, '000')) {
            preg_match('/src="(.*?)"/', $xxx, $xxx);
            $xxx = $xxx[1];
        }
        return $xxx;
    }
}

if (!function_exists('caiji_rep')) {
    function caiji_rep($xxx = null, $rep1 = null, $rep2 = null, $rep3 = null)
    {
        if ($rep1 && $rep2) {
            if (strstr($rep2, '000')) {
                $rep2 = str_replace('000', '', $rep2);
                $rep2 = trim($rep2);
                if ($rep2) {
                    $arr = explode(PHP_EOL, $rep2);
                    foreach ($arr as $k => $v) {
                        if (strstr($v, '♂')) {
                            $x = explode('♂', $v);
                            $x01 = $x[0];
                            $x02 = $x[1];
                            $xxx = str_replace($x01, $x02, $xxx);
                        } else {
                            $xxx = str_replace($v, '', $xxx);
                        }
                    }
                }
                $arr = explode('[内容]', $rep1);
                $x01 = $arr[0];
                $x02 = $arr[1];
                preg_match_all('/' . $x01 . '(.*?)' . $x02 . '/', $xxx, $arr);
                $xxx = $arr[1];
            } else {
                $rep1 = $rep1 ? str_replace('/', '\/', $rep1) : '';
                $rep2 = $rep2 ? str_replace('/', '\/', $rep2) : '';
                $rep3 = $rep3 ? str_replace('/', '\/', $rep3) : '';
                $x01 = '{page}';
                $x02 = '{/page}';
                $xxx = preg_replace('/' . $rep1 . '/', $x01, $xxx);
                $xxx = strstr($xxx, $x01);
                $len = strlen($x01);
                $xxx = substr($xxx, $len);
                $xxx = preg_replace('/' . $rep2 . '/', $x02, $xxx);
                $x = strstr($xxx, $x02);
                $xxx = str_replace($x, '', $xxx);
            }
        }
        if (!is_array($xxx)) {
            $xxx = trim($xxx);
        }
        if ($rep3) {
            $k2x = '{page}';
            $rep3 = str_replace("\n", PHP_EOL, $rep3);
            $arr = explode(PHP_EOL, $rep3);
            foreach ($arr as $k => $v) {
                $v = trim($v);
                $arr2 = explode('♂', $v);
                $k2 = $arr2[0];
                $v2 = isset($arr2[1]) ? $arr2[1] : '';
                $xxx = preg_replace('/' . $k2 . '/', $k2x, $xxx);
                $xxx = str_replace($k2x, $v2, $xxx);
            }
        }
        if (!is_array($xxx)) {
            $xxx = trim($xxx);
            $xxx = str_replace('\\/', '/', $xxx);
        }
        return $xxx;
    }
}

function caiji_request($url = null)
{
    $url = trim($url);
    $xxx = caiji_url($url);
    $e = mb_detect_encoding($xxx, array('ASCII', 'GB2312', 'GBK', 'UTF-8'));
    if ($e != 'UTF-8') {
        //$xxx = mb_convert_encoding($xxx, $e, "UTF-8");
        $xxx = iconv($e, 'UTF-8', $xxx);
    }
    $arr = explode('//', $url);
    $x01 = $arr[0];
    $x = $arr[1];
    $arr = explode('/', $x);
    $x02 = $arr[0];
    $x = $x01 . '//' . $x02 . '/';
    $xxx = str_replace('"//', '"https://', $xxx);
    $xxx = str_replace("'//", "'https://", $xxx);
    $xxx = str_replace('"/', '"' . $x, $xxx);
    $xxx = str_replace("'/", "'" . $x, $xxx);
    $xxx = str_replace($x . '/' . $x02 . '/', $x, $xxx);
    $xxx = str_replace($x . '/', $x, $xxx);
    $xxx = str_replace($x . '/', $x01 . '//', $xxx);
    return $xxx;
}

function caiji_url($url)
{
    try {
        if (strstr($url, 'http')) {
            $t1 = microtime(true);
            $curl = curl_init();
            curl_setopt($curl, CURLOPT_URL, $url);
            curl_setopt($curl, CURLOPT_CONNECTTIMEOUT, 5);
            curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
            curl_setopt($curl, CURLOPT_TIMEOUT, 5);
            curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, 0);
            $xxx = curl_exec($curl);
            curl_close($curl);
            $t2 = microtime(true);
            $x = $t2 - $t1;
        }
        if (!$xxx && $x < 5) {
            ini_set('default_socket_timeout', 1);
            $x = array(
                "ssl" => array(
                    "verify_peer" => false,
                    "verify_peer_name" => false,
                ),
                'http' => [
                    'timeout' => 10, // 设置超时时间为10秒  
                ],
            );
            $xxx = file_get_contents($url, false, stream_context_create($x));
        }
        return $xxx;
    } catch (\Exception $e) {
        caiji_url($url);
    }
}

function caiji_href($xxx = null, $url = null, $rep1 = null, $rep2 = null)
{
    if (!is_array($xxx)) {
        $xxx = str_replace('href ', 'href', $xxx);
        $xxx = str_replace(array(PHP_EOL, "\n"), '', $xxx);
        $xxx = preg_replace('/<img(.*?)>/', '', $xxx);
        preg_match_all('/href=((.|\n)+?)<\/a/', $xxx, $arr);
        $arr = $arr[1];
    } else {
        $arr = $xxx;
    }
    if ($rep1) {
        $rep1 = explode('|', $rep1);
    }
    if ($rep2) {
        $rep2 = explode('|', $rep2);
    }
    $xxxarr = array();
    foreach ($arr as $k => $v) {
        if (!$v) {
            continue;
        }
        $v = strip_tags($v);
        $v = trim($v);
        $v = trim($v, '"');
        $v = trim($v, "'");
        $v = preg_replace('/ (.*?)>/', ',', $v);
        $v = preg_replace('/"(.*?)>/', ',', $v);
        $v = preg_replace('/\'(.*?)>/', ',', $v);
        $v = preg_replace('/"(.*?),/', ',', $v);
        $v = preg_replace('/\'(.*?),/', ',', $v);
        $v = str_replace(array(PHP_EOL, '	', "\n"), '', $v);
        $v = trim($v);
        $x = substr($v, 0, 4);
        if ($x != 'http') {
            $x = substr($v, 0, 1);
            if ($x == '/') {
                $x = explode('//', $url);
                $x01 = $x[0];
                $x02 = $x[1];
                $x = explode('/', $x02);
                $x = $x[0];
                $v = $x01 . '//' . $x . $v;
            } else {
                $x = explode('/', $url);
                $x = $x[count($x) - 1];
                $x = str_replace($x, '', $url);
                $v = $x . $v;
            }
        }
        $x = explode(',', $v);
        $x01 = $x[0];
        $x02 = $x[1];
        if ($rep1) {
            foreach ($rep1 as $k2 => $v2) {
                if (!strstr($x01, $v2)) {
                    $x01 = '';
                    break;
                }
            }
        }
        if ($x01 && $rep2) {
            foreach ($rep2 as $k2 => $v2) {
                if (strstr($x01, $v2)) {
                    $x01 = '';
                    break;
                }
            }
        }
        if (!is_array($xxx) && (!$x01 || !$x02)) {
            continue;
        }
        if ($x02) {
            $xxxarr[$x02] = $x01;
        } else {
            if (!$x01) {
                continue;
            }
            $xxxarr[] = $x01;
        }
    }
    $xxx = array_unique($xxxarr);
    return $xxx;
}

// 获取转义数据，支持字符串、数组、对象
function escape_string($string)
{
    if (! $string)
        return $string;
    if (is_array($string)) { // 数组处理
        foreach ($string as $key => $value) {
            $string[$key] = escape_string($value);
        }
    } elseif (is_object($string)) { // 对象处理
        foreach ($string as $key => $value) {
            $string->$key = escape_string($value);
        }
    } else { // 字符串处理
        $string = htmlspecialchars(trim($string), ENT_QUOTES, 'UTF-8');
        $string = addslashes($string);
    }
    return $string;
}

function cjhash($x = null)
{
    $x = md5($x);
    $x = crc32($x);
    $xxx = sprintf("%u", $x);
    return $xxx;
}

function isfinish($subtitle = null)
{
    $isfinish = 1;
    $over = 0;
    if ($subtitle) {
        $overarr = array('完结', '完本', '全本', '写完', '完成');
        foreach ($overarr as $k => $v) {
            if (strstr($subtitle, $v)) {
                $over = '1';
                break;
            }
        }
        if ($over) {
            $isfinish = 2;
        }
    }
    return $isfinish;
}

function caiji_category($scode = 0, $name = null)
{
    $genre = 14;
    $subgenre = 0;
    if (intval($scode) > 0) {
        $cate = Db::name('category')->where(['id' => $scode])->find();
        if (!empty($cate)) {
            if (intval($cate['pid']) > 0) {
                $genre = $cate['pid'];
                $subgenre = $cate['id'];
            } else {
                $genre = $cate['id'];
            }
        }
    } else {
        $len = mb_strlen($name);
        $cate = Db::name('category')->where(['name' => $name])->find();
        if (empty($cate)) {
            if ($len > 2) {
                $name = mb_substr($name, 0, 2);
                $cate = Db::name('category')->where(['name' => $name])->find();
                if (empty($cate)) {
                    $name = mb_substr($name, 2);
                    $cate = Db::name('category')->where(['name' => $name])->find();
                }
                if (empty($cate)) {
                    $cate = Db::name('category')->where(['name' => '其他'])->find();
                }
            } else {
                if (empty($cate)) {
                    $cate = Db::name('category')->where(['name' => '其他'])->find();
                }
            }
            if (!empty($cate)) {
                if (intval($cate['pid']) > 0) {
                    $genre = $cate['pid'];
                    $subgenre = $cate['id'];
                } else {
                    $genre = $cate['id'];
                }
            }
        } else {
            if (intval($cate['pid']) > 0) {
                $genre = $cate['pid'];
                $subgenre = $cate['id'];
            } else {
                $genre = $cate['id'];
            }
        }
    }
    return [$genre, $subgenre];
}

function cjfilename($title = null)
{
    if (empty($title)) return '';
    $filename = Pinyin::permalink($title, '');
    $fn = '';
    $x = Db::name('book')->where(['filename' => $filename])->find();
    if (!empty($x)) {
        $fn = $x['id'];
    }
    return [$filename, $fn];
}

if (!function_exists('format_category')) {
    //递归排序，用于分类选择
    function format_category($result, $pid = 0, $level = -1)
    {
        /*记录排序后的类别数组*/
        static $list = array();
        static $space = ['', '├─', '§§├─', '§§§§├─', '§§§§§§├─'];
        $level++;
        foreach ($result as $k => $v) {
            if ($v['pid'] == $pid) {
                if ($pid != 0) {
                    $v['name'] = $space[$level] . $v['name'];
                }
                /*将该类别的数据放入list中*/
                $list[] = $v;
                format_category($result, $v['id'], $level);
            }
        }
        return $list;
    }
}

function ico2local($img = null, $id = null)
{
    if (!$img || !$id) {
        return false;
    }
    $path = app()->getRootPath() . 'public/storage/bookcover/' . $id . '/';
    if (!createDirectory($path)) {
        return false;
    }
    $filename = pathinfo($img, PATHINFO_BASENAME);
    $localpath = get_config('filesystem.disks.public.url') . '/bookcover/' . $id . '/' . $filename;
    $save_path = $path . $filename;
    ob_start();
    readfile($img);
    $img = ob_get_contents();
    ob_end_clean();
    $fp2 = @fopen($save_path, 'a');
    fwrite($fp2, $img);
    fclose($fp2);
    if (!is_file($save_path)) return '';
    $filesize = filesize($save_path);
    if ($filesize < 0) {
        unlink($save_path);
        $localpath = '';
    }
    return $localpath;
}
